/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   HW3jonesjn6.cpp
 * Author: josh
 *
 * Created on February 26, 2020, 2:54 PM
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

/*
 * 
 */

void list() {
    //open file
    ifstream inFile;
    inFile.open("movies_db.txt");
    
    //Variables
    int moveID, year, imdbID, numRaters;
    std::string title, genres, header;
    float rating;
    
    //Get rid of header
    getline(inFile, header);
    
    //List off movies
    while(moveID != 51412) {
        //Read in
        inFile >> moveID >>  quoted(title) >> year >> quoted(genres) >> imdbID 
                >> rating >> numRaters; 
    
        //Read out
        cout << moveID << " " << title << " " << year << " " << genres << " " 
                << imdbID << " " << rating << " " << numRaters << endl;
    }
    
    //close file
    inFile.close();
}

void search(std::string titleGiven) {
    //open file
    ifstream inFile;
    inFile.open("movies_db.txt");
    
    //Variables
    int moveID, year, imdbID, numRaters;
    std::string title, genres, header;
    float rating;
    int found = 0;
    
    //Get rid of header
    getline(inFile, header);
    
    //Print out matching titles
    while(moveID != 51412) {
        //Read in
        inFile >> moveID >>  quoted(title) >> year >> quoted(genres) >> imdbID 
                >> rating >> numRaters; 
    
        //Read out match
        if(title.find(titleGiven) != string::npos) {
            cout << moveID << " " << title << " " << year << " " << genres << 
                    " " << imdbID << " " << rating << " " << numRaters << endl;
            found++;
        }
    }
    
    // Listings found
    cout << "Found " << found << " match(s)" << endl;
    
    //close file
    inFile.close();
}

void find(int num) {
    //open file
    ifstream inFile;
    inFile.open("movies_db.txt");
    
    //Variables
    int moveID, year, imdbID, numRaters;
    std::string title, genres, header;
    float rating;
    bool found = false;
    
    //Get rid of header
    getline(inFile, header);
    
    //Print out matching number
    while(moveID != 51412) {
        //Read in
        inFile >> moveID >>  quoted(title) >> year >> quoted(genres) >> imdbID 
                >> rating >> numRaters; 
    
        //Read out match
        if(moveID == num) {
            found = true;
            cout << moveID << " " << title << " " << year << " " << genres << 
                    " " << imdbID << " " << rating << " " << numRaters << endl;
        }
    }
    
    //Display if not found
    if(!found) {
        cout << "Movie with ID " << num << " not found in database." << endl;
    }
    
    //close file
    inFile.close();
}

int main(int argc, char** argv) {
    bool active = true;
    std::string command = "";
    std::string title;
    int num;
    
    while(active) {
        cout << "Enter a command:" << endl;
        cin >> command;
        if(command == "exit") active = false;
        if(command == "list") list();
        if(command == "search") {
            cin >> title;
            search(title);
        }
        if(command == "find") {
            cin >> num;
            find(num);
        }
        if(command != "exit") cout << endl;
    }
    return 0;
}

